package nejad_p3;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner scnr = new Scanner(System.in);
        String[] topics = {"Dogs", "Cats", "Mokeys", "Fish", "Birds"};
        int[][] responses = new int [topics.length][];
        int people, rating;

        for(int i=0; i<responses.length; i++) {
               responses[i] = new int[10];
               for(int j=0; j < responses[i].length; j++) {
            	   responses[i][j] = 0; //initialize the responses array with all zeros
               }
        }
        System.out.print("How many people are rating?: ");
        people = scnr.nextInt();

        for(int i=0; i < people; i++) {
        	System.out.println("Rate each animal below from 1(low) to 10(high)\n\n");
        	for(int j=0; j < topics.length; j++) {
                      System.out.print("Enter your rating for "+ topics[j] + ": ");
                      rating = scnr.nextInt();

                      responses[j][rating-1]++;
               }
        }       
        
        scnr.close();
        int avgRating[] = new int[topics.length];
        String highestPointIssue = "";
        String lowestPointIssue = "";
        int highestPointTotal = 0; 
        int lowestPointTotal= 0;    
        
        for(int i=0; i < responses.length; i++) {
               avgRating[i] = 0;
               for(int j=0; j < responses[i].length; j++)
                      avgRating[i] += (responses[i][j] * (j + 1));
               if(i == 0) {
                      highestPointTotal = avgRating[i];
                      lowestPointTotal = avgRating[i];
                      highestPointIssue = topics[i];
                      lowestPointIssue = topics[i];
               } else {
                      if(avgRating[i] > highestPointTotal) {
                            highestPointIssue = topics[i];
                            highestPointTotal = avgRating[i];
                      }                     
                      if(avgRating[i] < lowestPointTotal) {
                            lowestPointIssue = topics[i];
                            lowestPointTotal = avgRating[i];
                      }
               }              
               avgRating[i] = avgRating[i] / people;
        }
        
        System.out.printf("\n%-10s","");
        for(int i=0; i < 10; i++)
               System.out.printf("%-10d", (i + 1));
        System.out.printf("%10s", "Average Rating");
        System.out.println();
        for(int i=0; i < responses.length; i++) {
        	System.out.printf("\n%-10s", topics[i]);
        	
        	for(int j=0; j < responses[i].length; j++)
        		System.out.printf("%-10d", responses[i][j]);
        	
        	System.out.printf("%-10d", avgRating[i]);

        }

        System.out.println("\nHighest Point Total: "  + highestPointTotal + "\tAnimal : " + highestPointIssue);
        System.out.println("Lowest Point Total: " + lowestPointTotal + "\tAnimal : " + lowestPointIssue);
  }

}
