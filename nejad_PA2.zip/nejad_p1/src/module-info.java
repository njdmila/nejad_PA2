module nejad_p1 {
}