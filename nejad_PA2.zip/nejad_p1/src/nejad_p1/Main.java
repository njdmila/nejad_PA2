package nejad_p1;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
	       Scanner scnr = new Scanner(System.in);
	       System.out.print("Enter a 4 digit integer: ");
	       String number = scnr.nextLine();
	       scnr.close();
	       String encryptedNumber = encrypt(number);
	       System.out.println("Encrypted Value: " + encryptedNumber);
	       String decryptedNumber = decrypt(encryptedNumber);
	       System.out.println("Decrypted Value: " + decryptedNumber);
	      
	   }
	
	public static String encrypt(String number) {
	       int arr[] = new int[4];
	       for(int i=0; i<4; i++) {
	           char ch = number.charAt(i); //pull character value from number
	           arr[i] = Character.getNumericValue(ch); //turns string to int
	       }
	       for(int i=0; i<4; i++) {
	           int x = arr[i] ;
	           x = (x + 7) % 10; //runs conversion on the numbers in arr
	           arr[i] = x ;
	       }
	       int x = arr[0];
	       arr[0] = arr[2];
	       arr[2]= x;
	       x = arr[1];
	       arr[1] = arr[3];
	       arr[3] = x;
	       int y = 0 ;
	       for(int i=0; i<4; i++)
	           y = y * 10 + arr[i];
	       String out = Integer.toString(y);
	       if(arr[0] == 0)
	           out = "0" + out;
	       return out;
	   }
	   public static String decrypt(String number) {
	       int arr[] = new int[4];
	       for(int i=0; i<4; i++) {
	           char ch = number.charAt(i);
	           arr[i] = Character.getNumericValue(ch);
	       }
	       int temp = arr[0];
	       arr[0] = arr[2];
	       arr[2] = temp;
	       temp = arr[1];
	       arr[1] = arr[3];
	       arr[3] = temp;
	       for(int i=0; i<4; i++) {
	           int x = arr[i];
	           switch(x) {
	               case 0:
	                   arr[i] = 3;
	                   break;
	               case 1:
	                   arr[i] = 4;
	                   break;
	               case 2:
	                   arr[i] = 5;
	                   break;
	               case 3:
	                   arr[i] = 6;
	                   break;
	               case 4:
	                   arr[i] = 7;
	                   break;
	               case 5:
	                   arr[i] = 8;
	                   break;
	               case 6:
	                   arr[i] = 9;
	                   break;
	               case 7:
	                   arr[i] = 0;
	                   break;
	               case 8:
	                   arr[i] = 1;
	                   break;
	               case 9:
	                   arr[i] = 2;
	                   break;
	           }
	       }
	       int y = 0 ;
	       for(int i=0; i<4; i++)
	           y = y * 10 + arr[i];
	       String out = Integer.toString(y);
	       if(arr[0] == 0)
	           out = "0" + out;
	       return out;
	}

}
