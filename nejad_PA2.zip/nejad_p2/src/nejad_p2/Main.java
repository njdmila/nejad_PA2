package nejad_p2;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		double pounds, inches, kilograms, meters;
		double BMI = 0;
		Scanner scnr = new Scanner(System.in);
		
		System.out.print("Select Calculation Mode\n\nEnter lb or kg: ");
		String option = scnr.nextLine();
		switch(option.toLowerCase())
		{
		case "lb":
			System.out.print("\nEnter weight in pounds: ");
			pounds = scnr.nextDouble();
			System.out.print("\nEnter height in inches: ");
			inches = scnr.nextDouble();
			BMI = (703 * pounds) / (inches * inches);
			break;
		case "kg":
			System.out.print("\nEnter weight in kilograms: ");
			kilograms = scnr.nextDouble();
			System.out.print("\nEnter height in meters: ");
			meters = scnr.nextDouble();
			scnr.close();
			BMI = kilograms / (meters * meters);
			break;
		default:
			System.out.println("Not an option. Try again");
			break;
		}
		if(BMI<=18.5)
			System.out.println("BMI: " + BMI + "\nBMI < 18.5: UnderWeight");
		else if(BMI<=24.9)
			System.out.println("BMI: " + BMI + "\nBMI between 18.5-24.9: Normal Weight");
		else if(BMI<=29.9)
			System.out.println("BMI: " + BMI + "\nBMI between 25.0-29.9: Overweight");
		else
			System.out.println("BMI: " + BMI + "\nBMI ≥ to 30.0: Obese");
	}
	
}

