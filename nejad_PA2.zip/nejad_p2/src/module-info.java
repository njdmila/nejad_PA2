module nejad_p2 {
}